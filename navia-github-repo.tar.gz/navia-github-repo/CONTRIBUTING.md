# Contributing to Navia

First off, thank you for considering contributing to Navia! 🎉

## 🌟 How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check the existing issues to avoid duplicates. When you create a bug report, include as many details as possible:

- **Use a clear and descriptive title**
- **Describe the exact steps to reproduce the problem**
- **Provide specific examples**
- **Describe the behavior you observed and what you expected**
- **Include screenshots if possible**
- **Note your environment** (OS, Node version, etc.)

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion:

- **Use a clear and descriptive title**
- **Provide a detailed description** of the suggested enhancement
- **Explain why this enhancement would be useful**
- **List some examples** of how it would work

### Pull Requests

1. **Fork the repo** and create your branch from `main`
2. **Make your changes**
3. **Test your changes** thoroughly
4. **Update documentation** if needed
5. **Ensure code follows** the existing style
6. **Write clear commit messages**
7. **Submit a pull request**

## 🎨 Style Guidelines

### Git Commit Messages

- Use the present tense ("Add feature" not "Added feature")
- Use the imperative mood ("Move cursor to..." not "Moves cursor to...")
- Limit the first line to 72 characters or less
- Reference issues and pull requests after the first line

Examples:
```
feat: Add gate location markers to compass
fix: Resolve navigation pulse timing issue
docs: Update installation guide with API keys
style: Format code according to ESLint rules
refactor: Simplify Compass component logic
test: Add unit tests for WingmateMessage
```

### JavaScript Style Guide

- Use ES6+ features
- Follow ESLint configuration
- Use meaningful variable names
- Add comments for complex logic
- Keep functions small and focused

### React/React Native Best Practices

- Use functional components with hooks
- Keep components pure when possible
- Use proper prop types
- Avoid inline styles (use StyleSheet)
- Follow component file structure

## 📁 Project Structure

```
navia-app/
├── src/
│   ├── components/      # React components
│   ├── styles/          # Theme and global styles
│   ├── config/          # Configuration files
│   ├── services/        # API services
│   ├── utils/           # Utility functions
│   └── hooks/           # Custom hooks
├── docs/                # Documentation
└── public/              # Static assets
```

## 🧪 Testing

- Write tests for new features
- Ensure all tests pass before submitting PR
- Aim for high test coverage

Run tests:
```bash
npm test
```

## 📝 Documentation

- Update README.md if needed
- Add JSDoc comments to functions
- Update docs/ folder for major changes
- Include examples for new features

## 💬 Code Review Process

1. Maintainers will review your PR
2. Address any requested changes
3. Once approved, your PR will be merged
4. Your contribution will be credited

## 🎯 Development Process

1. **Check existing issues** or create a new one
2. **Comment on the issue** to claim it
3. **Create a branch** from `main`
4. **Make your changes**
5. **Test thoroughly**
6. **Submit PR** with reference to issue
7. **Respond to review** feedback
8. **Celebrate** when merged! 🎉

## 🏆 Recognition

Contributors will be:
- Listed in README.md
- Credited in release notes
- Thanked in our community

## 📞 Questions?

- Open an issue with the `question` label
- Join our Discord (link in README)
- Email: contribute@navia.com

## ⚖️ Code of Conduct

By participating, you agree to uphold our [Code of Conduct](CODE_OF_CONDUCT.md).

---

**Thank you for contributing to Navia!** 💙🧭✈️
